# NanoFi Feature Export

This export contains all features related to:
1. **Signup/Signin Authentication**
2. **Vaults & Tokenize Patent**
3. **Profile Management**

## 📁 Directory Structure

```
export_features/
├── src/
│   ├── pages/
│   │   ├── Login.tsx              # Login page
│   │   ├── Signup.tsx              # Signup page
│   │   ├── Profile.tsx             # Profile main page
│   │   ├── EditProfile.tsx         # Edit profile page
│   │   ├── Vault.tsx               # Vault main page
│   │   └── TokenizePatent.tsx      # Tokenize patent page
│   ├── components/
│   │   ├── ProtectedRoute.tsx      # Route protection component
│   │   ├── vault/                  # Vault components
│   │   │   ├── VaultHero.tsx
│   │   │   ├── VaultStats.tsx
│   │   │   ├── PatentTable.tsx
│   │   │   ├── TokenizeSteps.tsx
│   │   │   └── BenefitsSection.tsx
│   │   ├── patent-form/            # Patent tokenization form components
│   │   │   ├── PatentVaultForm.tsx
│   │   │   ├── PatentDetailsSection.tsx
│   │   │   ├── InventorSection.tsx
│   │   │   ├── CommercialValueSection.tsx
│   │   │   ├── DocumentationSection.tsx
│   │   │   ├── ValuationSection.tsx
│   │   │   ├── OwnershipSection.tsx
│   │   │   ├── NFTMintingSection.tsx
│   │   │   ├── SignSubmitSection.tsx
│   │   │   └── FormSection.tsx
│   │   └── profile/                # Profile components
│   │       ├── ProfileSidebar.tsx
│   │       ├── ProfileOverview.tsx
│   │       ├── WalletsSection.tsx
│   │       ├── MyIPNFTsSection.tsx
│   │       ├── LendingFundingSection.tsx
│   │       ├── PortfolioSection.tsx
│   │       └── SecuritySettingsSection.tsx
│   ├── contexts/
│   │   └── AuthContext.tsx         # Authentication context
│   └── lib/
│       ├── validation.ts            # Validation schemas
│       └── vaultStorage.ts          # Vault storage utilities
└── README.md                        # This file
```

## 🔐 Authentication Features

### Login & Signup
- **Login.tsx**: User login page with form validation
- **Signup.tsx**: User registration page
- **AuthContext.tsx**: Authentication state management
- **ProtectedRoute.tsx**: Route protection wrapper component

### Key Features:
- Email/password authentication
- User role management (SPV, regular users)
- Protected routes
- Session management

## 🏦 Vault & Tokenize Patent Features

### Vault Page
- **Vault.tsx**: Main vault page displaying patents
- **VaultHero.tsx**: Hero section with tokenize button
- **VaultStats.tsx**: Statistics cards
- **PatentTable.tsx**: Table displaying all patents
- **TokenizeSteps.tsx**: Step-by-step guide
- **BenefitsSection.tsx**: Benefits information

### Tokenize Patent Form
- **TokenizePatent.tsx**: Main tokenize page
- **PatentVaultForm.tsx**: Multi-step form container
- **PatentDetailsSection.tsx**: Basic patent information
- **InventorSection.tsx**: Inventor details
- **CommercialValueSection.tsx**: Commercial value assessment
- **DocumentationSection.tsx**: Technical documentation
- **ValuationSection.tsx**: Patent valuation
- **OwnershipSection.tsx**: Ownership information
- **NFTMintingSection.tsx**: NFT minting configuration
- **SignSubmitSection.tsx**: Final review and submission

### Key Features:
- Multi-step form with validation
- Auto-save functionality
- Progress tracking
- File upload support
- Form validation with Zod

## 👤 Profile Features

### Profile Pages
- **Profile.tsx**: Main profile page with sidebar navigation
- **EditProfile.tsx**: Edit profile information page

### Profile Components
- **ProfileSidebar.tsx**: Navigation sidebar
- **ProfileOverview.tsx**: Profile overview dashboard
- **WalletsSection.tsx**: Connected wallets management
- **MyIPNFTsSection.tsx**: User's IP-NFTs display
- **LendingFundingSection.tsx**: Lending and funding history
- **PortfolioSection.tsx**: Portfolio overview
- **SecuritySettingsSection.tsx**: Security and privacy settings

### Key Features:
- Tab-based navigation
- Responsive design (mobile-friendly)
- Multiple profile sections
- Wallet integration
- Portfolio tracking

## 📦 Dependencies

These features require the following dependencies (from package.json):
- `react-router-dom`: Routing
- `react-hook-form`: Form handling
- `@hookform/resolvers/zod`: Form validation
- `zod`: Schema validation
- `lucide-react`: Icons
- `@radix-ui/*`: UI components (shadcn-ui)

## 🚀 Integration Notes

1. **Routes**: Add these routes to your `App.tsx`:
   ```tsx
   <Route path="/login" element={<Login />} />
   <Route path="/signup" element={<Signup />} />
   <Route path="/profile" element={<Profile />} />
   <Route path="/profile/edit" element={<EditProfile />} />
   <Route path="/vault" element={<Vault />} />
   <Route path="/vault/tokenize" element={<TokenizePatent />} />
   ```

2. **Auth Provider**: Wrap your app with `AuthProvider`:
   ```tsx
   <AuthProvider>
     <App />
   </AuthProvider>
   ```

3. **Protected Routes**: Use `ProtectedRoute` for authenticated pages:
   ```tsx
   <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
   ```

## 📝 Notes

- All components use TypeScript
- Styling uses Tailwind CSS
- Form validation uses Zod schemas
- Components are mobile-responsive
- Uses shadcn-ui component library

## 🔄 Version

Export Date: $(date)
Project: NanoFi Development Dashboard

